//
//  FLReachability.m
//  Reachability
//
//  Created by Mac on 2019/8/14.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import "FLReachability.h"

// 单例标记
static dispatch_once_t onceToken;

// 单例
static FLReachability *instance;

@implementation FLReachability

// 获取单例
+ (instancetype)sharedInstance
{
    return [[self alloc] init];
}

// 创建单例
+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
    dispatch_once(&onceToken, ^{
        if (instance == nil) {
            instance = [super allocWithZone:zone];
        }
    });
    return instance;
}

// 复制对象
- (id)copyWithZone:(NSZone *)zone
{
    return instance;
}

// 复制对象
- (id)mutableCopyWithZone:(NSZone *)zone
{
    return instance;
}

// 销毁单例
+ (void)destroyInstance
{
    onceToken = 0;
    instance = nil;
}

@end
