//
//  FLReachability.h
//  Reachability
//
//  Created by Mac on 2019/8/14.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import "Reachability.h"

NS_ASSUME_NONNULL_BEGIN

@interface FLReachability : Reachability

+ (instancetype)sharedInstance;

@end

NS_ASSUME_NONNULL_END
