#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
#define kFLAddReachabilityStatusChangedObserver(observer) \
[[NSNotificationCenter defaultCenter] addObserver:observer selector:@selector(handleReachabilityStatusChangedNotification:) name:kFLReachabilityStatusChangedNotification object:nil]; \
FLLog(@"[ OBSERVER ] Added to reachability helper", @"[ USING ] Notification")
#define kFLRemoveReachabilityStatusChangedObserver(observer) \
[[NSNotificationCenter defaultCenter] removeObserver:observer name:kFLReachabilityStatusChangedNotification object:nil]; \
FLLog(@"[ OBSERVER ] Removed from reachability helper", @"[ USING ] Notification")
#define FLHandleReachabilityStatusChangedNotification(notification) \
- (void)handleReachabilityStatusChangedNotification:(NSNotification *)notification
#define kFLGetCurrentReachabilityStatus(status) \
FLReachabilityHelper *reachabilityHelper = notification.object; \
FLReachabilityStatus status = [reachabilityHelper currentReachabilityStatus]
typedef NS_ENUM(NSUInteger, FLReachabilityStatus) {
    FLReachabilityStatusNone = 0,   
    FLReachabilityStatusWiFi,       
    FLReachabilityStatus2G,         
    FLReachabilityStatus3G,         
    FLReachabilityStatus4G,         
    FLReachabilityStatusUnknown     
};
extern NSString * _Nonnull const FLReachabilityStatusConvert[];
extern NSString * const kFLReachabilityStatusChangedNotification;
@class FLReachabilityHelper;
@protocol FLReachabilityHelperDelegate <NSObject>
- (void)reachabilityHelper:(FLReachabilityHelper *)reachabilityHelper reachabilityStatusChanged:(FLReachabilityStatus)status;
@end
@interface FLReachabilityHelper : NSObject
@property (nonatomic, weak) id<FLReachabilityHelperDelegate> delegate;
#pragma mark -
+ (instancetype)helperWithHostName:(NSString *)hostName;
+ (instancetype)helperWithAddress:(const struct sockaddr *)address;
+ (instancetype)helper;
#pragma mark -
- (BOOL)startMonitor;
- (BOOL)stopMonitor;
#pragma mark -
- (void)addMonitor:(id)monitor reachabilityStatusChangedBlock:(nonnull void (^)(FLReachabilityStatus status))block;
- (void)addMonitor:(id)monitor;
- (void)removeMonitor:(id)monitor;
- (FLReachabilityStatus)currentReachabilityStatus;
@end
NS_ASSUME_NONNULL_END
