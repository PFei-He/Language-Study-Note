#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface FLCryptor : NSObject
+ (void)AES256Passwords:(NSArray<NSString *> *)passwords;
+ (NSData *)decryptAES256:(NSString *)string;
+ (NSString *)encryptAES256:(NSData *)data;
+ (NSString *)encryptMD5:(NSString *)string;
@end
NS_ASSUME_NONNULL_END
