#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN
@interface FLHUD : NSObject
+ (void)show;
+ (void)showWithContent:(nullable NSArray *)content;
+ (void)showWithContent:(nullable NSArray *)content addedTo:(nullable UIView *)view;
+ (void)hide;
+ (void)hideForView:(nullable UIView *)view;
@end
NS_ASSUME_NONNULL_END
