#import <Foundation/Foundation.h>
#import <Security/Security.h>
@interface FLKeychainWrapper : NSObject
@property (nonatomic, copy) NSString *service;
@property (nonatomic, copy) NSString *accessGroup;
- (void)setValue:(NSString *)value forKey:(NSString *)key;
- (NSString *)valueForKey:(NSString *)key;
- (BOOL)deleteValueForKey:(NSString *)key;
@end
