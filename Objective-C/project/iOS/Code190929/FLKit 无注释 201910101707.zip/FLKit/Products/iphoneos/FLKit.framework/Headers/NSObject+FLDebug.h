#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
#define FL_LIB_NAME(name) \
+ (NSString *)libName { \
return name; \
}
#define FL_CLASS_NAME(name) \
+ (NSString *)className { \
return name; \
}
#define FLLog(args...) \
[self debugLog:args, nil]
@interface NSObject (FLDebug)
@property (nonatomic, readonly) BOOL currentDebugMode;
+ (void)setDebugMode:(BOOL)openOrNot;
- (void)debugLog:(NSString *)strings, ...;
@end
NS_ASSUME_NONNULL_END
