#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface NSObject (FLURL)
- (NSString *)serializeParameters:(NSDictionary *)parameters;
- (NSString *)queryStringForURLParameter:(NSString *)parameter;
@end
NS_ASSUME_NONNULL_END
