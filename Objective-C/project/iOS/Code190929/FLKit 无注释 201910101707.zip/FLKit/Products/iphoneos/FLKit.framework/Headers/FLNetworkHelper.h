#import <Foundation/Foundation.h>
#import "FLModel.h"
NS_ASSUME_NONNULL_BEGIN
#define FLHandleRequestSuccessNotification(notification) \
- (void)handleRequestSuccessNotification:(NSNotification *)notification
#define FLHandleRequestFailureNotification(notification) \
- (void)handleRequestFailureNotification:(NSNotification *)notification
#define kFLResponse \
[FLResponse modelWithJSON:notification.userInfo]
@class FLNetworkHelper;
@protocol FLNetworkHelperDelegate <NSObject>
@optional
- (void)networkHelper:(FLNetworkHelper *)networkHelper dataTask:(NSURLSessionDataTask *)dataTask resultData:(id)resultData;
- (void)networkHelper:(FLNetworkHelper *)networkHelper dataTask:(NSURLSessionDataTask *)dataTask error:(NSError *)error;
@end
typedef NS_ENUM(NSUInteger, FLNetworkRequestMethod) {
    FLNetworkRequestMethodGet,
    FLNetworkRequestMethodPut,
    FLNetworkRequestMethodPost,
    FLNetworkRequestMethodDelete
};
@interface FLNetworkHelper : NSObject
@property (nonatomic) FLNetworkRequestMethod requestMethod;
@property (nonatomic, copy) NSString *requestURL;
@property (nonatomic, copy) NSDictionary *requestHeaders;
@property (nonatomic, copy) NSDictionary *requestParams;
@property (nonatomic) NSTimeInterval timeoutInterval;
@property (nonatomic) NSInteger retryTimes;
@property (nonatomic, copy) NSArray<NSHTTPCookie *> *cookies;
@property (nonatomic, weak) id<FLNetworkHelperDelegate> delegate;
- (NSURLSessionDataTask *)sendRequestSuccess:(nullable void (^)(NSURLSessionDataTask *dataTask, id resultData))success failure:(nullable void (^)(NSURLSessionDataTask *dataTask, NSError *error))failure;
- (NSURLSessionDataTask *)sendRequest;
- (NSURLSessionDataTask *)sendRequestForReceiver:(id)receiver;
@end
@interface FLResponse : FLModel
@property (nonatomic, strong) NSURLSessionDataTask *dataTask;
@property (nonatomic, strong) id resultData;
@property (nonatomic, strong) NSError *error;
@end
NS_ASSUME_NONNULL_END
