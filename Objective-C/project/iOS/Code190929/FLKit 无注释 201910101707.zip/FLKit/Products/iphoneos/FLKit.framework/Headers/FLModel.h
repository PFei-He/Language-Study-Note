#import <Foundation/Foundation.h>
@interface FLModel : NSObject
@property (strong, nonatomic) id JSON;
@property (strong, nonatomic) id XML;
- (instancetype)initWithJSON:(id)JSON;
+ (instancetype)modelWithJSON:(id)JSON;
- (instancetype)initWithXML:(id)XML;
+ (instancetype)modelWithXML:(id)XML;
+ (instancetype)model;
- (NSDictionary *)propertyConvert;
- (NSArray *)propertyList;
@end
