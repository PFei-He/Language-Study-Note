#ifndef FLMacro_h
#define FLMacro_h
#ifndef weakify_self
    #if __has_feature(objc_arc)
        #define weakify_self autoreleasepool{} __weak __typeof__(self) weakSelf = self;
    #else
        #define weakifySelf autoreleasepool{} __block __typeof__(self) blockSelf = self;
    #endif
#endif
#ifndef strongify_self
    #if __has_feature(objc_arc)
        #define strongify_self try{} @finally{} __typeof__(weakSelf) self = weakSelf;
    #else
        #define strongify_self try{} @finally{} __typeof__(blockSelf) self = blockSelf;
    #endif
#endif
#ifndef weakify_
    #if __has_feature(objc_arc)
        #define weakify_(object) autoreleasepool{} __weak __typeof__(object) weak##_##object = object;
    #else
        #define weakify_(object) autoreleasepool{} __block __typeof__(object) block##_##object = object;
    #endif
#endif
#ifndef strongify_
    #if __has_feature(objc_arc)
        #define strongify_(object) try{} @finally{} __typeof__(object) object = weak##_##object;
    #else
        #define strongify_(object) try{} @finally{} __typeof__(object) object = block##_##object;
    #endif
#endif
#endif 
