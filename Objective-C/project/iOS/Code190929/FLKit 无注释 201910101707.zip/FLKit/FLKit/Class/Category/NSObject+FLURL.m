#import "NSObject+FLURL.h"
@implementation NSObject (FLURL)
- (NSString *)serializeParameters:(NSDictionary *)parameters
{
    NSMutableArray *pairs = NSMutableArray.array;
    for (NSString *key in parameters.keyEnumerator) {
        id value = parameters[key];
        if ([value isKindOfClass:[NSDictionary class]]) {
            for (NSString *subKey in value) {
                [pairs addObject:[NSString stringWithFormat:@"%@[%@]=%@", key, subKey, [value objectForKey:subKey]]];
            }
        } else if ([value isKindOfClass:[NSArray class]]) {
            for (NSString *subValue in value) {
                [pairs addObject:[NSString stringWithFormat:@"%@[]=%@", key, subValue]];
            }
        } else {
            [pairs addObject:[NSString stringWithFormat:@"%@=%@", key, [NSString stringWithFormat:@"%@", value]]];
        }
    }
    return [pairs componentsJoinedByString:@"&"];
}
- (NSString *)queryStringForURLParameter:(NSString *)parameter
{
    return [parameter stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
}
@end
