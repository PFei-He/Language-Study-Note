#import "FLHUD.h"
#import "MBProgressHUD.h"
@implementation FLHUD
#pragma mark - Private Methods
+ (UIViewController *)currentViewController
{
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    UIViewController *viewController = keyWindow.rootViewController;
    while (viewController.presentedViewController) {
        if ([viewController.presentedViewController isKindOfClass:[UINavigationController class]]) {
            viewController = [(UINavigationController *)viewController visibleViewController];
        } else if ([viewController isKindOfClass:[UITabBarController class]]) {
            viewController = [(UITabBarController *)viewController selectedViewController];
        }
    }
    return viewController;
}
#pragma mark - Public Methods
+ (void)show
{
    [self showWithContent:nil];
}
+ (void)showWithContent:(NSArray *)content
{
    [self showWithContent:content addedTo:nil];
}
+ (void)showWithContent:(NSArray *)content addedTo:(UIView *)view
{
    if (!view) view = [self currentViewController].view;
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    if (content) {
        hud.mode = MBProgressHUDModeText;
        hud.label.text = content[0];
        hud.detailsLabel.text = content[1];
        [hud hideAnimated:YES afterDelay:2];
    }
}
+ (void)hide
{
    [self hideForView:nil];
}
+ (void)hideForView:(UIView *)view
{
    if (!view) view = [self currentViewController].view;
    [MBProgressHUD hideHUDForView:view animated:YES];
}
@end
