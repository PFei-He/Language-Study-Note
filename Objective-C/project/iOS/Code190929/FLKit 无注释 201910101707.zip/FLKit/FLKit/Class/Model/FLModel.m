#import "FLModel.h"
#import <objc/runtime.h>
#import "NSObject+FLDebug.h"
@interface FLModel () <NSXMLParserDelegate>
@property (strong, nonnull) NSMutableDictionary *undefinedProperty;
@property (strong, nonatomic) NSMutableArray *elements;
@property (strong, nonatomic) NSMutableString *elementName;
@end
@implementation FLModel (Property)
#pragma mark - Private Methods
- (NSArray *)propertyList:(Class)cls
{
    unsigned int propertyCount = 0;
    NSMutableArray *propertyArray = [NSMutableArray array];
    objc_property_t *propertyList = class_copyPropertyList(cls, &propertyCount);
    if (propertyList != NULL) {
        for (unsigned int i = 0; i < propertyCount; i++) {
            NSString *key = [NSString stringWithUTF8String:property_getName(propertyList[i])];
            [propertyArray addObject:key];
        }
    }
    free(propertyList);
    return propertyArray;
}
@end
@implementation FLModel (JSON)
#pragma mark - Private Methods
- (void)parseJSON:(id)JSON
{
    if ([JSON isKindOfClass:[NSDictionary class]]) {
        [self setValuesForKeysWithDictionary:JSON];
        [self undefinedKeyConvert];
        [self undefinedKey];
    } else if ([JSON isKindOfClass:[NSData class]]) {
        NSError *error;
        JSON = [NSJSONSerialization JSONObjectWithData:JSON options:NSJSONReadingAllowFragments error:&error];
        if (error) {
            FLLog(@"[ ERROR ] The JSON object can't be parsed");
        } else {
            [self setValuesForKeysWithDictionary:JSON];
            [self undefinedKeyConvert];
            [self undefinedKey];
        }
    } else {
        FLLog(@"[ ERROR ] The JSON object must be type of 'NSDictionary' or 'NSData'");
    }
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if (!self.undefinedProperty) {
        self.undefinedProperty = [NSMutableDictionary dictionary];
    }
    [self.undefinedProperty setValue:value forKey:key];
}
- (void)undefinedKeyConvert
{
    __weak __typeof__(self) weakSelf = self;
    [self.undefinedProperty enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        __typeof__(weakSelf) self = weakSelf;
        if ([self propertyConvert]) { 
            NSDictionary *conversionTable = [self propertyConvert];
            for (int i=0; i < conversionTable.count; i++) {
                NSString *beforeRename = conversionTable.allKeys[i];
                NSString *afterRename = conversionTable.allValues[i];
                if ([key isEqualToString:beforeRename]) {
                    [self setValue:obj forKeyPath:afterRename];
                    [self.undefinedProperty removeObjectForKey:key];
                    FLLog(@"[ DEBUG ] Property name converted",
                          [NSString stringWithFormat:@"[ BEFORE ] %@", beforeRename],
                          [NSString stringWithFormat:@"[ AFTER ] %@", afterRename]);
                }
            }
        }
    }];
}
- (void)undefinedKey
{
    __weak __typeof__(self) weakSelf = self;
    [self.undefinedProperty enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        __typeof__(weakSelf) self = weakSelf;
        FLLog(@"[ WARNING ] Found undefined key when parsing",
              [NSString stringWithFormat:@"[ KEY ] %@", key],
              [NSString stringWithFormat:@"[ VALUE ] %@", obj],
              [NSString stringWithFormat:@"[ TYPE ] %@", [obj classForCoder]]);
    }];
}
@end
@implementation FLModel (XML)
#pragma mark - Private Methods
- (void)parseXML:(id)XML
{
    if (!self.elements) self.elements = [[NSMutableArray alloc] init];
    [self.elements addObject:[NSMutableDictionary dictionary]];
    if (!self.elementName) self.elementName = [[NSMutableString alloc] init];
    if ([XML isKindOfClass:[NSData class]]) {
        if ([self XMLParser:XML]) { 
            self.JSON = self.elements[0];
        } else {
            FLLog(@"[ ERROR ] The XML object can't be parsed");
        }
    } else if ([XML isKindOfClass:[NSString class]]) {
        XML = [XML dataUsingEncoding:NSUTF8StringEncoding];
        if ([self XMLParser:XML]) { 
            self.JSON = self.elements[0];
        } else {
            FLLog(@"[ ERROR ] The XML object can't be parsed");
        }
    } else {
        FLLog(@"[ ERROR ] The XML object must be type of 'NSString' or 'NSData'");
    }
}
- (BOOL)XMLParser:(id)XML
{
    NSXMLParser *parser = [[NSXMLParser alloc] initWithData:XML];
    parser.delegate = self;
    return [parser parse];
}
#pragma mark - NSXMLParserDelegate Implementation
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary<NSString *,NSString *> *)attributeDict
{
    NSMutableDictionary *parentElement = [self.elements lastObject];
    NSMutableDictionary *childElement = [NSMutableDictionary dictionary];
    [childElement addEntriesFromDictionary:attributeDict];
    id value = parentElement[elementName];
    if (value) {
        NSMutableArray *array = nil;
        if ([value isKindOfClass:[NSMutableArray class]]) {
            array = (NSMutableArray *)value;
        } else {
            array = [NSMutableArray array];
            [array addObject:value];
            [parentElement setObject:array forKey:elementName];
        }
        [array addObject:childElement];
    } else {
        [parentElement setObject:childElement forKey:elementName];
    }
    [self.elements addObject:childElement];
}
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    NSMutableDictionary *dictionary = self.elements.lastObject;
    if (self.elementName.length > 0) { 
        NSString *string = [self.elementName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        [dictionary setObject:string forKey:elementName];
        self.elementName = [NSMutableString new];
    }
    [self.elements removeLastObject];
}
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    [self.elementName appendString:string];
}
@end
@implementation FLModel
FL_CLASS_NAME(@"MODEL")
#pragma mark - Life Cycle
- (instancetype)initWithJSON:(id)JSON
{
    self.JSON = JSON;
    return [self init];
}
+ (instancetype)modelWithJSON:(id)JSON
{
    return [[self alloc] initWithJSON:JSON];
}
- (instancetype)initWithXML:(id)XML
{
    self.XML = XML;
    return [self init];
}
+ (instancetype)modelWithXML:(id)XML
{
    return [[self alloc] initWithXML:XML];
}
+ (instancetype)model
{
    return [[self alloc] init];
}
#pragma mark - Setter/Getter Methods
- (id)JSON
{
    return [self createJSON];
}
- (void)setJSON:(id)JSON
{
    [self parseJSON:JSON];
}
- (void)setXML:(id)XML
{
    _XML = XML;
    [self parseXML:XML];
}
#pragma mark - Private Methods
- (NSDictionary *)createJSON
{
    NSDictionary *propertyDictionary = [NSDictionary dictionaryWithDictionary:[self dictionaryWithValuesForKeys:[self propertyList:[self class]]]];
    NSMutableDictionary *JSON = [NSMutableDictionary dictionary];
    for (NSString *key in propertyDictionary) {
        if ([propertyDictionary[key] isKindOfClass:[NSNull class]]) {
            [JSON setValue:nil forKey:key];
        } else {
            [JSON setValue:propertyDictionary[key] forKey:key];
        }
    }
    return JSON;
}
#pragma mark - Public Methods
- (NSDictionary *)propertyConvert
{
    return nil;
}
- (NSArray *)propertyList
{
    return [self propertyList:[self class]];
}
@end
