#import "NSObject+FLDebug.h"
#import <objc/runtime.h>
@implementation NSObject (FLDebug)
static char const * const currentDebugModeKey;
@dynamic currentDebugMode;
#pragma mark - Getter / Setter Methods
- (BOOL)currentDebugMode
{
    return [objc_getAssociatedObject(self, &currentDebugModeKey) boolValue];
}
- (void)setCurrentDebugMode:(BOOL)currentDebugMode
{
    objc_setAssociatedObject(self, &currentDebugModeKey, [NSNumber numberWithBool:currentDebugMode], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
#pragma mark - Public Methods
+ (NSString *)libName
{
    return @"FayLIB";
}
+ (NSString *)className
{
    return @"CLASS";
}
+ (void)setDebugMode:(BOOL)debugMode
{
    [self setCurrentDebugMode:debugMode];
}
- (void)debugLog:(NSString *)strings, ...
{
    if (self.class.currentDebugMode) {
        NSString *lib = [[self class] libName];
        NSString *cls = [[self class] className];
        if ([strings hasPrefix:@"[ "]) NSLog(@"[ %@ ][ %@ ]%@.", lib, cls, strings);
        else NSLog(@"[ %@ ][ %@ ][ DEBUG ] %@.", lib, cls, strings);
        va_list list;
        va_start(list, strings);
        while (strings != nil) {
            NSString *string = va_arg(list, NSString *);
            if (!string) break;
            if ([strings hasPrefix:@"[ "]) NSLog(@"[ %@ ][ %@ ]%@.", lib, cls, string);
            else NSLog(@"[ %@ ][ %@ ][ DEBUG ] %@.", lib, cls, string);
        }
        va_end(list);
    }
}
@end
