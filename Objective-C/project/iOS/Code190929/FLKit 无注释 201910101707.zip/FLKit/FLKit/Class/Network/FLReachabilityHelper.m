#import <netdb.h>
#import <ifaddrs.h>
#import <arpa/inet.h>
#import <netinet/in.h>
#import <sys/socket.h>
#import <CoreFoundation/CoreFoundation.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import "NSObject+FLDebug.h"
#import "FLReachabilityHelper.h"
typedef void(^FLReachabilityStatusCallbackBlock)(void);
typedef void(^FLReachabilityStatusChangedBlock)(FLReachabilityStatus);
NSString * const kFLReachabilityStatusChangedNotification = @"kFLReachabilityStatusChangedNotification";
NSString * const kFLReachabilityStatusChangedBlock = @"kFLReachabilityStatusChangedBlock";
static void FLReachabilityCallback(SCNetworkReachabilityRef ref, SCNetworkReachabilityFlags flags, void* info);
static const void * FLReachabilityCallbackCopy(const void *info);
static void FLReachabilityCallbackRelease(const void *info);
NSString * const FLReachabilityStatusConvert[6] = {
    [FLReachabilityStatusNone] = @"None",
    [FLReachabilityStatusWiFi] = @"WiFi",
    [FLReachabilityStatus2G] = @"2G",
    [FLReachabilityStatus3G] = @"3G",
    [FLReachabilityStatus4G] = @"4G",
    [FLReachabilityStatusUnknown] = @"Unknown"
};
#pragma mark -
@interface FLReachabilityHelper ()
@property (nonatomic, strong) NSPointerArray *delegates;
@property (nonatomic, strong) NSMapTable *monitors;
@property (nonatomic, strong) NSMutableDictionary *blocks;
@property (nonatomic, assign) SCNetworkReachabilityRef reachabilityRef;
@property (nonatomic, assign) FLReachabilityStatus previousStatus;
@property (nonatomic) NSInteger blocksCount;
@end
@implementation FLReachabilityHelper
FL_CLASS_NAME(@"REACHABILITY")
#pragma mark - Life Cycle
+ (instancetype)helperWithHostName:(NSString *)hostName
{
    FLReachabilityHelper *reachabilityHelper = NULL;
    SCNetworkReachabilityRef reachabilityRef = SCNetworkReachabilityCreateWithName(kCFAllocatorDefault, [hostName UTF8String]);
    if (reachabilityRef != NULL) {
        reachabilityHelper = [[self alloc] init];
        if (reachabilityHelper != NULL) {
            reachabilityHelper.reachabilityRef = reachabilityRef;
            reachabilityHelper.previousStatus = FLReachabilityStatusUnknown;
        } else {
            CFRelease(reachabilityRef);
        }
    }
    return reachabilityHelper;
}
+ (instancetype)helperWithAddress:(const struct sockaddr *)hostAddress
{
    FLReachabilityHelper *reachabilityHelper = NULL;
    SCNetworkReachabilityRef reachabilityRef = SCNetworkReachabilityCreateWithAddress(kCFAllocatorDefault, hostAddress);
    if (reachabilityRef != NULL) {
        reachabilityHelper = [[self alloc] init];
        if (reachabilityHelper != NULL) {
            reachabilityHelper.reachabilityRef = reachabilityRef;
            reachabilityHelper.previousStatus = FLReachabilityStatusUnknown;
        } else {
            CFRelease(reachabilityRef);
        }
    }
    return reachabilityHelper;
}
+ (instancetype)helper
{
    struct sockaddr_in zeroAddress;
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.sin_len = sizeof(zeroAddress);
    zeroAddress.sin_family = AF_INET;
    return [self helperWithAddress:(const struct sockaddr *)&zeroAddress];
}
- (void)dealloc
{
    [self stopMonitor];
    if (self.reachabilityRef != NULL) {
        CFRelease(self.reachabilityRef);
    }
}
#pragma mark - Getter / Setter Methods
- (NSPointerArray *)delegates
{
    if (!_delegates) {
        _delegates = [NSPointerArray weakObjectsPointerArray];
    }
    return _delegates;
}
- (NSMapTable *)monitors
{
    if (!_monitors) {
        _monitors = [NSMapTable mapTableWithKeyOptions:NSPointerFunctionsStrongMemory valueOptions:NSPointerFunctionsWeakMemory];
    }
    return _monitors;
}
- (NSMutableDictionary *)blocks
{
    if (!_blocks) {
        _blocks = [NSMutableDictionary dictionary];
    }
    return _blocks;
}
- (void)setDelegate:(id<FLReachabilityHelperDelegate>)delegate
{
    if ([delegate respondsToSelector:@selector(reachabilityHelper:reachabilityStatusChanged:)]) {
        [self.delegates addPointer:(__bridge void*)delegate];
        FLLog(@"[ MONITOR ] Added", [NSString stringWithFormat:@"[ CLASS ] %@", [delegate class]], @"[ USING ] Delegate");
    }
}
#pragma mark - Private Methods
- (FLReachabilityStatus)currentStatus
{
    FLReachabilityStatus status = FLReachabilityStatusUnknown;
    SCNetworkReachabilityFlags flags;
    if (SCNetworkReachabilityGetFlags(self.reachabilityRef, &flags)) {
        status = [self networkStatusForFlags:flags];
    }
    return status;
}
- (FLReachabilityStatus)networkStatusForFlags:(SCNetworkReachabilityFlags)flags
{
    if ((flags & kSCNetworkReachabilityFlagsReachable) == 0) { 
        return FLReachabilityStatusNone;
    }
    FLReachabilityStatus status = FLReachabilityStatusUnknown;
    if ((flags & kSCNetworkReachabilityFlagsConnectionRequired) == 0) { 
        status = FLReachabilityStatusWiFi;
    }
    if ((((flags & kSCNetworkReachabilityFlagsConnectionOnDemand) != 0) || (flags & kSCNetworkReachabilityFlagsConnectionOnTraffic) != 0)) { 
        if ((flags & kSCNetworkReachabilityFlagsInterventionRequired) == 0) { 
            status = FLReachabilityStatusWiFi;
        }
    }
    if ((flags & kSCNetworkReachabilityFlagsIsWWAN) == kSCNetworkReachabilityFlagsIsWWAN) { 
        CTTelephonyNetworkInfo *info = [CTTelephonyNetworkInfo new];
        if ([info respondsToSelector:@selector(currentRadioAccessTechnology)]) {
            NSArray *type2G = @[CTRadioAccessTechnologyGPRS, CTRadioAccessTechnologyEdge, CTRadioAccessTechnologyCDMA1x];
            NSArray *type3G = @[CTRadioAccessTechnologyWCDMA, CTRadioAccessTechnologyHSDPA, CTRadioAccessTechnologyHSUPA, CTRadioAccessTechnologyCDMAEVDORev0, CTRadioAccessTechnologyCDMAEVDORevA, CTRadioAccessTechnologyCDMAEVDORevB, CTRadioAccessTechnologyeHRPD];
            NSArray *type4G = @[CTRadioAccessTechnologyLTE];
            NSString *generation = info.currentRadioAccessTechnology;
            if ([type2G containsObject:generation]) {
                status = FLReachabilityStatus2G;
            } else if ([type3G containsObject:generation]) {
                status = FLReachabilityStatus3G;
            } else if ([type4G containsObject:generation]){
                status = FLReachabilityStatus4G;
            }
        }
    }
    return status;
}
- (void)reachabilityChanged
{
    FLLog(@"[ STATUS ] Changed", [NSString stringWithFormat:@"[ TYPE ] %@", FLReachabilityStatusConvert[self.previousStatus]]);
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.blocks.count != 0) {
            NSArray *keys = [[self.blocks allKeys] sortedArrayUsingSelector:@selector(compare:)];
            NSArray *monitors = [[self.monitors keyEnumerator] allObjects];
            for (NSString *key in keys) {
                if ([monitors containsObject:key]) {
                    FLReachabilityStatusChangedBlock block = self.blocks[key];
                    block(self.previousStatus);
                } else {
                    [self.blocks removeObjectForKey:key];
                }
            }
        }
    });
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.delegates.count != 0) {
            for (id<FLReachabilityHelperDelegate> delegate in self.delegates) {
                [delegate reachabilityHelper:self reachabilityStatusChanged:self.previousStatus];
            }
        }
    });
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:kFLReachabilityStatusChangedNotification object:self];
    });
}
#pragma mark - Public Methods
- (BOOL)startMonitor
{
    BOOL started = NO;
    FLReachabilityStatusCallbackBlock callback = ^() {
        if (self.previousStatus != [self currentStatus]) {
            self.previousStatus = [self currentStatus];
            [self reachabilityChanged];
        }
    };
    SCNetworkReachabilityContext context = {0, (__bridge void *)callback, FLReachabilityCallbackCopy, FLReachabilityCallbackRelease, NULL};
    if (SCNetworkReachabilitySetCallback(self.reachabilityRef, FLReachabilityCallback, &context)) {
        if (SCNetworkReachabilityScheduleWithRunLoop(self.reachabilityRef, CFRunLoopGetCurrent(), kCFRunLoopDefaultMode)) {
            started = YES;
            FLLog(@"[ MONITOR ] Started");
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                SCNetworkReachabilityFlags flags;
                if (SCNetworkReachabilityGetFlags(self.reachabilityRef, &flags)) {
                    FLReachabilityCallback(self.reachabilityRef, flags, (__bridge void *)(callback));
                }
            });
        }
    }
    return started;
}
- (BOOL)stopMonitor
{
    BOOL stopped = NO;
    if (self.reachabilityRef != NULL) {
        if (SCNetworkReachabilityUnscheduleFromRunLoop(self.reachabilityRef, CFRunLoopGetCurrent(), kCFRunLoopDefaultMode)) {
            stopped = YES;
            FLLog(@"[ MONITOR ] Stopped");
        }
    }
    return stopped;
}
#pragma mark -
- (void)addMonitor:(id)monitor reachabilityStatusChangedBlock:(void (^)(FLReachabilityStatus))block
{
    [self.monitors setObject:monitor forKey:[NSString stringWithFormat:@"%@_%ld", kFLReachabilityStatusChangedBlock, (long)self.blocksCount]];
    [self.blocks setObject:block forKey:[NSString stringWithFormat:@"%@_%ld", kFLReachabilityStatusChangedBlock, (long)self.blocksCount]];
    self.blocksCount++;
    FLLog(@"[ MONITOR ] Added", [NSString stringWithFormat:@"[ CLASS ] %@", [monitor class]], @"[ USING ] Block");
}
- (void)addMonitor:(id)monitor
{
    [[NSNotificationCenter defaultCenter] addObserver:monitor selector:NSSelectorFromString(@"handleReachabilityStatusChangedNotification:") name:kFLReachabilityStatusChangedNotification object:nil];
    FLLog(@"[ MONITOR ] Added", [NSString stringWithFormat:@"[ CLASS ] %@", [monitor class]], @"[ USING ] Notification");
}
- (void)removeMonitor:(id)monitor
{
    [[NSNotificationCenter defaultCenter] removeObserver:monitor name:kFLReachabilityStatusChangedNotification object:nil];
    FLLog(@"[ MONITOR ] Removed", [NSString stringWithFormat:@"[ CLASS ] %@", [monitor class]], @"[ USING ] Notification");
}
- (FLReachabilityStatus)currentReachabilityStatus
{
    return self.previousStatus;
}
@end
#pragma mark - Supporting Functions
static void FLReachabilityCallback(SCNetworkReachabilityRef ref, SCNetworkReachabilityFlags flags, void* info) {
    FLReachabilityStatusCallbackBlock block = (__bridge FLReachabilityStatusCallbackBlock)info;
    block();
}
static const void * FLReachabilityCallbackCopy(const void* info) {
    return Block_copy(info);
}
static void FLReachabilityCallbackRelease(const void* info) {
    if (info) {
        Block_release(info);
    }
}
