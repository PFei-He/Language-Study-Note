#import "FLDebug.h"
#import "FLNetworkHelper.h"
#import "FLReachabilityHelper.h"
#import "FLCryptor.h"
#import "FLKeychainWrapper.h"
#import "NSObject+FLDebug.h"
@implementation FLDebug
+ (void)debugMode:(BOOL)openOrNot
{
    [FLModel setDebugMode:openOrNot];
    [FLNetworkHelper setDebugMode:openOrNot];
    [FLReachabilityHelper setDebugMode:openOrNot];
    [FLCryptor setDebugMode:openOrNot];
    [FLKeychainWrapper setDebugMode:openOrNot];
}
@end
