#import "FLKeychainWrapper.h"
@implementation FLKeychainWrapper
#pragma mark - Private Methods
- (NSMutableDictionary *)keychainQueryWithService:(NSString *)service account:(NSString *)account accessGroup:(NSString *)accessGroup
{
    NSMutableDictionary *query = [NSMutableDictionary dictionary];
    query[(__bridge id)kSecClass] = (__bridge id)kSecClassGenericPassword;
    query[(__bridge id)kSecAttrService] = service;
    query[(__bridge id)kSecAttrAccount] = account;
    query[(__bridge id)kSecAttrAccessGroup] = accessGroup;
    return query;
}
#pragma mark - Pubilc Methods
- (void)setValue:(NSString *)value forKey:(NSString *)key
{
    NSData *data = [value dataUsingEncoding:NSUTF8StringEncoding];
    if ([self valueForKey:key].length > 0) {
        NSMutableDictionary *updateAttributes = [NSMutableDictionary dictionary];
        updateAttributes[(__bridge id)kSecValueData] = data;
        NSMutableDictionary *query = [self keychainQueryWithService:self.service account:key accessGroup:self.accessGroup];
        SecItemUpdate((__bridge CFDictionaryRef)query, (__bridge CFDictionaryRef)updateAttributes);
    } else {
        NSMutableDictionary *attributes = [self keychainQueryWithService:self.service account:key accessGroup:self.accessGroup];
        attributes[(__bridge id)kSecValueData] = data;
        SecItemAdd((__bridge CFDictionaryRef)attributes, nil);
    }
}
- (NSString *)valueForKey:(NSString *)key
{
    NSMutableDictionary *attributes = [self keychainQueryWithService:self.service account:key accessGroup:self.accessGroup];
    attributes[(__bridge id)kSecMatchLimit] = (__bridge id)(kSecMatchLimitOne);
    attributes[(__bridge id)kSecReturnAttributes] = (__bridge id _Nullable)(kCFBooleanTrue);
    attributes[(__bridge id)kSecReturnData] = (__bridge id _Nullable)(kCFBooleanTrue);
    CFMutableDictionaryRef queryResult = nil;
    OSStatus keychainError = noErr;
    keychainError = SecItemCopyMatching((__bridge CFDictionaryRef)attributes, (CFTypeRef *)&queryResult);
    if (keychainError == errSecItemNotFound) {
        if (queryResult) CFRelease(queryResult);
        return nil;
    } else if (keychainError == noErr) {
        if (queryResult == nil) {
            return nil;
        }
        NSMutableDictionary *dictionary = (__bridge NSMutableDictionary *)queryResult;
        NSData *data = dictionary[(__bridge id)kSecValueData];
        NSString *value = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        return value;
    } else {
        if (queryResult) CFRelease(queryResult);
    }
    return nil;
}
- (BOOL)deleteValueForKey:(NSString *)key
{
    NSMutableDictionary *query = [self keychainQueryWithService:self.service account:key accessGroup:self.accessGroup];
    OSStatus status = SecItemDelete((__bridge CFDictionaryRef)query);
    if (status != noErr && status != errSecItemNotFound) {
        return NO;
    }
    return true;
}
@end
