#import "NSString+FLVersion.h"
@implementation NSString (FLVersion)
#pragma mark - Public Methods
- (NSString *)filling
{
    NSArray *fill = @[@"0000", @"000", @"00", @"0", @""];
    NSArray *array = [self componentsSeparatedByString:@"."];
    NSMutableArray *mutableArray = [NSMutableArray arrayWithArray:array];
    for (int i = 0; i < mutableArray.count; i++) {
        NSInteger index = [mutableArray[i] length];
        mutableArray[i] = [NSString stringWithFormat:@"%@%@", fill[index], mutableArray[i]];
    }
    return [mutableArray componentsJoinedByString:@""];
}
@end
