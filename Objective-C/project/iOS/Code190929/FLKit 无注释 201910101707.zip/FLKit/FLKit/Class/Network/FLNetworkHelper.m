#import "FLNetworkHelper.h"
#import "NSObject+FLDebug.h"
#import "NSObject+FLURL.h"
static dispatch_queue_t network_helper_queue() {
    static dispatch_queue_t network_helper_creation_queue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        network_helper_creation_queue = dispatch_queue_create("top.faylib.network.hepler.creation", DISPATCH_QUEUE_SERIAL);
    });
    return network_helper_creation_queue;
}
@interface FLNetworkHelper ()
@property (nonatomic) NSInteger retryTimesCount;
@property (nonatomic, copy) NSString *successNotificationName;
@property (nonatomic, copy) NSString *failureNotificationName;
@property (nonatomic, strong) id receiver;
@end
@implementation FLNetworkHelper
FL_CLASS_NAME(@"NETWORK")
NSString * const FLNetworkRequestMethodConvert[4] = {
    [FLNetworkRequestMethodGet] = @"GET",
    [FLNetworkRequestMethodPut] = @"PUT",
    [FLNetworkRequestMethodPost] = @"POST",
    [FLNetworkRequestMethodDelete] = @"DELETE"
};
#pragma mark - Getter / Setter Methods
- (NSTimeInterval)timeoutInterval
{
    if (_timeoutInterval == 0) {
        return 120;
    }
    return _timeoutInterval;
}
- (NSArray<NSHTTPCookie *> *)cookies
{
    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    return [storage cookies];
}
#pragma mark - Private Methods
- (NSURLSessionDataTask *)requestWithMethod:(NSString *)method URLString:(NSString *)URLString body:(id)body success:(void (^)(NSURLSessionDataTask * _Nonnull, id _Nullable))success failure:(void (^)(NSURLSessionDataTask * _Nonnull, NSError * _Nonnull))failure
{
    self.retryTimesCount--;
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:self.requestURL];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = FLNetworkRequestMethodConvert[self.requestMethod];
    request.timeoutInterval = self.timeoutInterval;
    [self.requestHeaders enumerateKeysAndObjectsUsingBlock:^(id _Nonnull field, id _Nonnull value, BOOL * _Nonnull stop) {
        [request setValue:value forHTTPHeaderField:field];
    }];
    request.HTTPBody = [[self serializeParameters:self.requestParams] dataUsingEncoding:NSUTF8StringEncoding];
    __block NSURLSessionDataTask *dataTask = nil;
    dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error) { 
            if (self.retryTimesCount < 1) {
                FLLog(@"[ REQUEST ] Failure", [NSString stringWithFormat:@"[ URL ] %@", request.URL]);
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (failure) failure(dataTask, error);
                });
                dispatch_async(dispatch_get_main_queue(), ^{
                    if ([self.delegate respondsToSelector:@selector(networkHelper:dataTask:error:)]) [self.delegate networkHelper:self dataTask:dataTask error:error];
                });
                dispatch_async(dispatch_get_main_queue(), ^{
                    [[NSNotificationCenter defaultCenter] postNotificationName:self.failureNotificationName object:self userInfo:@{@"dataTask": dataTask, @"error": error}];
                    [[NSNotificationCenter defaultCenter] removeObserver:self.receiver name:self.successNotificationName object:nil];
                    [[NSNotificationCenter defaultCenter] removeObserver:self.receiver name:self.failureNotificationName object:nil];
                });
            } else { 
                [self requestWithMethod:method URLString:URLString body:body success:success failure:failure];
            }
        } else { 
            NSDictionary *resultData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            FLLog(@"[ REQUEST ] Success", [NSString stringWithFormat:@"[ URL ] %@", request.URL]);
            dispatch_async(dispatch_get_main_queue(), ^{
                if (success) success(dataTask, resultData);
            });
            dispatch_async(dispatch_get_main_queue(), ^{
                if ([self.delegate respondsToSelector:@selector(networkHelper:dataTask:resultData:)]) [self.delegate networkHelper:self dataTask:dataTask resultData:resultData];
            });
            dispatch_async(dispatch_get_main_queue(), ^{
                [[NSNotificationCenter defaultCenter] postNotificationName:self.successNotificationName object:self userInfo:@{@"dataTask": dataTask, @"resultData": resultData}];
                [[NSNotificationCenter defaultCenter] removeObserver:self.receiver name:self.successNotificationName object:nil];
                [[NSNotificationCenter defaultCenter] removeObserver:self.receiver name:self.failureNotificationName object:nil];
            });
        }
    }];
    FLLog(@"[ REQUEST ] Sending",
          (self.retryTimes - self.retryTimesCount == 1) ? @"[ STATUS ] Start" : @"[ STATUS ] Retry",
          [NSString stringWithFormat:@"[ COUNT ] %@", @(self.retryTimes - self.retryTimesCount)],
          [NSString stringWithFormat:@"[ URL ] %@", request.URL],
          [NSString stringWithFormat:@"[ METHOD ] %@", request.HTTPMethod],
          [NSString stringWithFormat:@"[ TIMEOUT ] %@", @(request.timeoutInterval)],
          [NSString stringWithFormat:@"[ HEADERS ] %@", request.allHTTPHeaderFields],
          [NSString stringWithFormat:@"[ PARAMS ] %@", body]);
    [dataTask resume];
    return dataTask;
}
- (void)prase
{
}
#pragma mark - Public Methods
- (NSURLSessionDataTask *)sendRequestSuccess:(void (^)(NSURLSessionDataTask * _Nonnull, id _Nonnull))success failure:(void (^)(NSURLSessionDataTask * _Nonnull, NSError * _Nonnull))failure
{
    FLLog(@"[ REQUEST ] Added", @"[ USING ] Block");
    __block NSURLSessionDataTask *dataTask = nil;
    dispatch_sync(network_helper_queue(), ^{
        self.retryTimesCount = self.retryTimes = self.retryTimes < 1 ? 1 : self.retryTimes;
        dataTask = [self requestWithMethod:FLNetworkRequestMethodConvert[self.requestMethod] URLString:self.requestURL body:self.requestParams success:success failure:failure];
    });
    return dataTask;
}
- (NSURLSessionDataTask *)sendRequest
{
    FLLog(@"[ REQUEST ] Added", @"[ USING ] Delegate");
    __block NSURLSessionDataTask *dataTask = nil;
    dispatch_sync(network_helper_queue(), ^{
        self.retryTimesCount = self.retryTimes = self.retryTimes < 1 ? 1 : self.retryTimes;
        dataTask = [self requestWithMethod:FLNetworkRequestMethodConvert[self.requestMethod] URLString:self.requestURL body:self.requestParams success:nil failure:nil];
    });
    return dataTask;
}
- (NSURLSessionDataTask *)sendRequestForReceiver:(id)receiver
{
    FLLog(@"[ REQUEST ] Added", @"[ USING ] Notification");
    __block NSURLSessionDataTask *dataTask = nil;
    dispatch_sync(network_helper_queue(), ^{
        self.receiver = receiver;
        char data[8];
        for (int x = 0; x < 8; data[x++] = (char)('a' + (arc4random_uniform(26))));
        NSString *random = [[NSString alloc] initWithBytes:data length:8 encoding:NSUTF8StringEncoding];
        self.successNotificationName = [NSString stringWithFormat:@"%@%@RequestSuccessNotification", random, [receiver class]];
        [[NSNotificationCenter defaultCenter] addObserver:receiver selector:NSSelectorFromString(@"handleRequestSuccessNotification:") name:self.successNotificationName object:nil];
        self.failureNotificationName = [NSString stringWithFormat:@"%@%@RequestFailureNotification", random, [receiver class]];
        [[NSNotificationCenter defaultCenter] addObserver:receiver selector:NSSelectorFromString(@"handleRequestFailureNotification:") name:self.failureNotificationName object:nil];
        self.retryTimesCount = self.retryTimes = self.retryTimes < 1 ? 1 : self.retryTimes;
        dataTask = [self requestWithMethod:FLNetworkRequestMethodConvert[self.requestMethod] URLString:self.requestURL body:self.requestParams success:nil failure:nil];
    });
    return dataTask;
}
@end
@implementation FLResponse
@end
