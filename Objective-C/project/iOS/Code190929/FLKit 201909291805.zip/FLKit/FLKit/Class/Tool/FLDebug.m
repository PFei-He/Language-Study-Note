//
//  FLDebug.m
//  Runner
//
//  Created by Mac on 2019/9/25.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import "FLDebug.h"
#import "FLNetworkHelper.h"
#import "FLReachabilityHelper.h"
#import "FLCryptor.h"
#import "FLKeychainWrapper.h"

#import "NSObject+FLDebug.h"

@implementation FLDebug

+ (void)debugMode:(BOOL)openOrNot
{
    [FLModel setDebugMode:openOrNot];
    
    [FLNetworkHelper setDebugMode:openOrNot];
    [FLReachabilityHelper setDebugMode:openOrNot];
    
    [FLCryptor setDebugMode:openOrNot];
    [FLKeychainWrapper setDebugMode:openOrNot];
}

@end
