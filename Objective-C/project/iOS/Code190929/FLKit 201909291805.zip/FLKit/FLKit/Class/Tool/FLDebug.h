//
//  FLDebug.h
//  Runner
//
//  Created by Mac on 2019/9/25.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FLDebug : NSObject

+ (void)debugMode:(BOOL)openOrNot;

@end

NS_ASSUME_NONNULL_END
