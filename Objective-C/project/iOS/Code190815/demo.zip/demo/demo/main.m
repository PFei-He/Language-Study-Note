//
//  main.m
//  demo
//
//  Created by Mac on 2019/8/15.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Baker1.h"
#import "Baker2.h"
#import "Customer.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Baker1 *baker1 = [[Baker1 alloc] init];
        [baker1 startWorkInShop:[Shop open]];
        Baker2 *baker2 = [[Baker2 alloc] init];
        [baker2 startWorkInShop:[Shop open]];
        
        [Customer enter];
        
        [baker2 offWorkInShop:[Shop open]];
        
        [Customer enter];
    }
    return 0;
}
