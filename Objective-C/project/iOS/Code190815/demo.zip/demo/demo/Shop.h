//
//  Shop.h
//  demo
//
//  Created by Mac on 2019/8/15.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol Workshop <NSObject>

- (void)makingBread;

@end

@interface Shop : NSObject

@property (nonatomic, weak) id<Workshop> baker;

+ (Shop *)open;

- (void)bakerEnter:(id)baker workshop:(void (^)(void))makingBread;

- (void)bakerLeave:(id)baker;

- (void)order;

@end

NS_ASSUME_NONNULL_END
