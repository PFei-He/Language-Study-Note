//
//  Baker2.m
//  demo
//
//  Created by Mac on 2019/8/15.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import "Baker2.h"

@interface Baker2 () <Workshop>

@end

@implementation Baker2

- (void)startWorkInShop:(Shop *)shop
{
    shop.baker = self;
    
//    [shop bakerEnter:self workshop:^{
//        NSLog(@"Baker2 finish!");
//    }];
}

- (void)offWorkInShop:(Shop *)shop
{
//    [shop bakerLeave:self];
}

- (void)makingBread
{
    NSLog(@"Baker2 finish!");
}

@end
