//
//  Shop.m
//  demo
//
//  Created by Mac on 2019/8/15.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import "Shop.h"

typedef void(^Ability)(void);

@interface Shop ()

@property (nonatomic, strong) NSPointerArray *bakers;

@property (nonatomic, strong) NSMutableDictionary *ability;

@end

@implementation Shop

+ (Shop *)open
{
    static Shop *instanse;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instanse = [[Shop alloc] init];
    });
    return instanse;
}

- (void)setBaker:(id<Workshop>)baker
{
    [self.bakers addPointer:(__bridge void*)baker];
}

- (NSPointerArray *)bakers
{
    if (!_bakers) {
        _bakers = [NSPointerArray weakObjectsPointerArray];
    }
    return _bakers;
}

- (NSMutableDictionary *)ability
{
    if (!_ability) {
        _ability = [NSMutableDictionary dictionary];
    }
    return _ability;
}

- (void)bakerEnter:(id)baker workshop:(void (^)(void))makingBread
{
    [self.ability setObject:makingBread forKey:[baker className]];
}

- (void)bakerLeave:(id)baker
{
    [self.ability removeObjectForKey:[baker className]];
}

- (void)order
{
    for (id<Workshop> baker in self.bakers) {
        [baker makingBread];
    }
    
    for (Ability ability in self.ability.allValues) {
        ability();
    }
}

@end
