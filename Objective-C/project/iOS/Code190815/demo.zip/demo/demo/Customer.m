//
//  Customer.m
//  demo
//
//  Created by Mac on 2019/8/15.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import "Customer.h"

@implementation Customer

+ (void)enter
{
    [[Shop open] order];
}

@end
