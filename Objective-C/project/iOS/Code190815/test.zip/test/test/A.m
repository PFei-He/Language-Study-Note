//
//  A.m
//  test
//
//  Created by Mac on 2019/8/14.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import "A.h"
#import "D.h"

@interface A () <Delegate>

@end

@implementation A

- (void)run
{
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notification:) name:@"kA" object:nil];
    
    D *d = [D shareInstance];
    d.delegate = self;
    
//    [d cls:self block:^{
//        NSLog(@"3");
//    }];
}

//- (void)notification:(NSNotification *)notification
//{
//    NSLog(@"1");
//}

- (void)go
{
    NSLog(@"2");
}

@end
