//
//  main.m
//  test
//
//  Created by Mac on 2019/8/14.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "A.h"
#import "B.h"
#import "C.h"
#import "D.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        A *a = [[A alloc] init];
//        [a run];
//        B *b = [[B alloc] init];
//        [b run];
        C *c = [[C alloc] init];
        [c run];
//        c = nil;
        D *d = [D shareInstance];
        [d run];
        c = nil;
        [d run];
    }
    return 0;
}
