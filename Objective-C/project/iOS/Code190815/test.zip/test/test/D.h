//
//  D.h
//  test
//
//  Created by Mac on 2019/8/14.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol Delegate <NSObject>

- (void)go;

@end

@interface D : NSObject

@property (nonatomic, weak) id<Delegate> delegate;

+ (D *)shareInstance;

- (void)cls:(id)cls block:(void (^)(void))block;

- (void)run;

@end

NS_ASSUME_NONNULL_END
