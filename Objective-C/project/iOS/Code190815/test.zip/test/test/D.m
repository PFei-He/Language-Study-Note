//
//  D.m
//  test
//
//  Created by Mac on 2019/8/14.
//  Copyright © 2019 FayLib. All rights reserved.
//

#import "D.h"

typedef void(^Block)(void);

@interface D ()

@property (nonatomic, strong) NSPointerArray *delegates;

@property (nonatomic, strong) NSMutableDictionary *blocks;

@end

@implementation D

+ (D *)shareInstance
{
    static D *instanse;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instanse = [[D alloc] init];
    });
    return instanse;
}

- (void)setDelegate:(id<Delegate>)delegate
{
    if ([delegate respondsToSelector:@selector(go)]) {
        [self.delegates addPointer:(__bridge void*)delegate];
    }
}

- (NSPointerArray *)delegates
{
    if (!_delegates) {
        _delegates = [NSPointerArray weakObjectsPointerArray];
    }
    return _delegates;
}

- (NSMutableDictionary *)blocks
{
    if (!_blocks) {
        _blocks = [NSMutableDictionary dictionary];
    }
    return _blocks;
}

- (void)cls:(id)cls block:(void (^)(void))block
{
    [self.blocks setObject:block forKey:NSStringFromClass([cls classForCoder])];
}

- (void)run
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"kA" object:nil];
    
    for (id delegate in self.delegates) {
        [delegate go];
    }
    
    for (Block block in self.blocks.allValues) {
        block();
    }
}

@end
