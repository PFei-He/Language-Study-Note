//
//  Copyright (c) 2019 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

#import "Bakery.h"

// 店里的面包
typedef void(^Bread)(void);

@interface Bakery ()

// 面包店的所有面包师
@property (nonatomic, strong) NSPointerArray *bakers;

// 面包店的招牌面包
@property (nonatomic, strong) NSMutableDictionary *specialty;

@end

@implementation Bakery

// 开门
+ (instancetype)open
{
    return [[self alloc] init];
}

// 招聘面包师
- (void)setBaker:(id<Workshop>)baker
{
    // 加入面包店的阵容
    [self.bakers addPointer:(__bridge void*)baker];
}

// -
- (NSPointerArray *)bakers
{
    if (!_bakers) {
        _bakers = [NSPointerArray weakObjectsPointerArray];
    }
    return _bakers;
}

// -
- (NSMutableDictionary *)specialty
{
    if (!_specialty) {
        _specialty = [NSMutableDictionary dictionary];
    }
    return _specialty;
}

// 面包师上班，进入作坊
- (void)bakerStartWork:(id)baker enterWorkshop:(void (^)(void))makingBread
{
    // 记录不同面包师的不同招牌面包
    [self.specialty setObject:makingBread forKey:NSStringFromClass([baker classForCoder])];
}

// 面包师下班
- (void)bakerOffWork:(id)baker
{
    // 面包师离开了，对应的招牌面包就做不了
    [self.specialty removeObjectForKey:NSStringFromClass([baker classForCoder])];
}

// 下单
- (void)order
{
    // 通知面包师接单
    [[NSNotificationCenter defaultCenter] postNotificationName:@"kMakingBreadNotification" object:nil];
    
    // 分派面包师开始制作面包
    for (id<Workshop> baker in self.bakers) {
        [baker makingBread];
    }
    
    // 已经做好的面包，由已经上班的面包师制作
    for (Bread bread in self.specialty.allValues) {
        bread();
    }
}

@end
