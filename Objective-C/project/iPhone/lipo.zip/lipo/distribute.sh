lipo -create Desktop/lipo/iphoneos/libaxa.a Desktop/lipo/iphonesimulator/libaxa.a -output Desktop/lipo/libaxa.a
lipo -info Desktop/lipo/libaxa.a
rm Desktop/lipo/iphoneos/libaxa.a
rm Desktop/lipo/iphonesimulator/libaxa.a
