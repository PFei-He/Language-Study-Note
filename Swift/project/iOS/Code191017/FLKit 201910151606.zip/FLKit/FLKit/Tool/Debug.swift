//
//  Copyright (c) 2019 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

import Foundation

public protocol Debug: class {
    
    /**
     定义当前打印的包名
     
     ## 用于区分当前打印的内容属性哪个类库或工程
     
     - returns: 识别码
     */
    func libName() -> String
    
    /**
     定义当前打印的类名
     
     ## 用于区分当前打印的内容属性哪个类
     
     - returns: 识别码
     */
    func className() -> String
}

// 调试对象标记
private var debugKey: Void? = nil

// 当前调试模式标记
private var currentDebugModeKey: Void? = nil

extension NSObject {
    
    // 调试对象
    private weak var debug: Debug? {
        get { return objc_getAssociatedObject(self, &debugKey) as? Debug ?? nil }
        set { objc_setAssociatedObject(self, &debugKey, newValue, .OBJC_ASSOCIATION_ASSIGN) }
    }
    
    // 当前调试模式
    private class var currentDebugMode: Bool {
        get { return objc_getAssociatedObject(self, &currentDebugModeKey) as? Bool ?? false }
        set { objc_setAssociatedObject(self, &currentDebugModeKey, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC) }
    }
    
    /**
     设置调试模式
     
     - parameters:
     
        - openOrNot: 是否打开
     */
    public class func setDebugMode(_ openOrNot: Bool) {
        self.currentDebugMode = openOrNot
    }
    
    /**
     打印调试日志
     
     - parameters:
     
        - strings: 日志内容
     */
    public func log(_ strings: String ...) {
        if type(of: self).currentDebugMode {
            self.debug = self as? Debug
            for string in strings {
                if string.contains("[ ") && string.contains(" ]") {
                    print("[ \(debug?.libName() ?? "FayLIB") ][ \(debug?.className() ?? "Class") ]\(string).")
                } else {
                    print("[ \(debug?.libName() ?? "FayLIB") ][ \(debug?.className() ?? "Class") ][ DEBUG ] \(string).")
                }
            }
        }
    }
}
