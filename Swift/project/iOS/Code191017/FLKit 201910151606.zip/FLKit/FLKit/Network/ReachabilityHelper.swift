//
//  Copyright (c) 2019 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

import Foundation
import CoreTelephony
import SystemConfiguration

extension Notification.Name {
    /**
     网络可达性状态改变的通知名
     
     ## 使用通知监听网络可达性状态时监听此通知名，所有监听此通知名的类都会接收到网络可达性状态改变的消息
     
     - warning: 使用通知监听网络可达性状态时实现
     
     网络可达性助手集成了代理，闭包，通知三种方式进行网络可达性状态监听，使用时只需实现其中一种方式即可
     */
    public static let ReachabilityStatusChangedNotification = Notification.Name("ReachabilityStatusChangedNotification")
}

extension NSObject {
    /**
     添加网络可达性状态改变的监听者
     
     ## 此方法用于将监听者添加到网络可达性状态监听队列，所有实现此方法的类都会接收到网络可达性状态改变的消息
     
     使用此方法时不需实现 `addMonitor(_:)` 方法
     
     - parameters:
     
        - observer: 监听者
     
     - warning: 使用通知监听网络可达性状态时实现
     
     网络可达性助手集成了代理，闭包，通知三种方式进行网络可达性状态监听，使用时只需实现其中一种方式即可
     */
    public func addReachabilityStatusChangedObserver(_ observer: AnyObject) {
        NotificationCenter.default.addObserver(observer, selector: #selector(handleReachabilityStatusChangedNotification(_:)), name: Notification.Name.ReachabilityStatusChangedNotification, object: nil)
        self.log("[ OBSERVER ] Added to reachability helper", "[ USING ] Notification")
    }
    
    /**
     移除网络可达性状态改变的监听者
     
     ## 此方法用于将监听者从网络可达性状态监听队列移除
     
     使用此方法时不需实现 `removeMonitor(_:)` 方法
     
     - parameters:
     
        - observer: 监听者
     
     - warning: 使用通知监听网络可达性状态时实现
     
     网络可达性助手集成了代理，闭包，通知三种方式进行网络可达性状态监听，使用时只需实现其中一种方式即可
     */
    public func removeReachabilityStatusChangedObserver(_ observer: AnyObject) {
        NotificationCenter.default.removeObserver(observer, name: Notification.Name.ReachabilityStatusChangedNotification, object: nil)
        self.log("[ OBSERVER ] Removed from reachability helper", "[ USING ] Notification")
    }
    
    /**
     处理网络可达性状态改变的通知
     
     ## 该方法用于接收网络可达性状态发生改变的消息
     
     - parameters:
     
        - notification: 网络可达性状态改变的通知
     
     - warning: 使用通知监听网络可达性状态时实现
     
     网络可达性助手集成了代理，闭包，通知三种方式进行网络可达性状态监听，使用时只需实现其中一种方式即可
     */
    @objc open func handleReachabilityStatusChangedNotification(_ notification: Notification) {
        // Override
    }
    
    /**
     获取当前网络可达性状态
     
     ## 该方法用于接收当前已发生了改变的网络可达性状态
     
     - parameters:
     
        - notification: 网络可达性状态改变的通知
     
     - returns: 当前网络可达性状态
     
     - warning: 使用通知监听网络可达性状态时实现
     
     网络可达性助手集成了代理，闭包，通知三种方式进行网络可达性状态监听，使用时只需实现其中一种方式即可
     */
    public func getCurrentReachabilityStatus(reachabilityStatusChangedNotification notification: Notification) -> ReachabilityStatus {
        let helper = notification.object as! ReachabilityHelper
        return helper.currentReachabilityStatus()
    }
}

/**
 网络可达性状态
 */
public enum ReachabilityStatus: CustomStringConvertible {
    case none, wifi, wwan2G, wwan3G, wwan4G, unknown
    public var description: String {
        switch self {
        case .none:
            return "None"
        case .wifi:
            return "WiFi"
        case .wwan2G:
            return "2G"
        case .wwan3G:
            return "3G"
        case .wwan4G:
            return "4G"
        case .unknown:
            return "Unknown"
        }
    }
}

public protocol ReachabilityHelperDelegate: class {
    /**
     网络可达性状态发生改变的代理方法
     
     ## 此方法用于接收网络可达性状态改变的消息，由一个代理的队列管理，所有实现此代理方法的类都会接收到网络可达性状态改变的消息
     
     - parameters:
     
        - reachabilityHelper: 网络可达性助手
     
        - status: 网络可达性状态
     
     - warning: 使用代理监听网络可达性状态时实现
     
     网络可达性助手集成了代理，闭包，通知三种方式进行网络可达性状态监听，使用时只需实现其中一种方式即可
     */
    func reachabilityHelper(_ reachabilityHelper: ReachabilityHelper, reachabilityStatusChanged status: ReachabilityStatus)
}

public class ReachabilityHelper {
    // MARK: - Private Variable
    
    // 调试模式
    static var debugMode = false
    
    // 代理数组
    var delegates = NSPointerArray.weakObjects()
    
    // 监听者数组
    var monitors = NSMapTable<AnyObject, AnyObject>(keyOptions: NSPointerFunctions.Options.strongMemory, valueOptions: NSPointerFunctions.Options.weakMemory)
    
    // 闭包数组
    var closures = Dictionary<String, AnyObject>()
    
    // 闭包计数
    var closureCount = 0
    
    // 闭包计数名
    let kFLReachabilityStatusChangedClosure = "kFLReachabilityStatusChangedClosure"
    
    // 网络可达性
    private let reachability: SCNetworkReachability
    
    // 上一个网络状态
    private var previousStatus = ReachabilityStatus.unknown
    
    // 网络可达性状态的回调
    private typealias ReachabilityStatusCallbackClosure = () -> Void
    private var reachabilityStatusCallback: ReachabilityStatusCallbackClosure?
    
    // 网络可达性状态改变的回调
    private typealias ReachabilityStatusChangedClosure = (ReachabilityStatus) -> Void
    
    // MARK: - Public Variable
    
    /**
     网络可达性助手代理
     
     ## 此代理将被作为监听者添加到网络可达性状态监听队列
     
     若此监听者被从内存中释放，监听队列会自动移除此监听者，不需手动管理
     
     - warning: 使用代理监听网络可达性状态时实现
     
     网络可达性助手集成了代理，闭包，通知三种方式进行网络可达性状态监听，使用时只需实现其中一种方式即可
     */
    public weak var delegate: ReachabilityHelperDelegate? {
        get {
            return _delegate
        } set {
            delegates.addObject(newValue)
            
            log("[ MONITOR ] Added", "[ CLASS ] \(NSStringFromClass(type(of: newValue!) as AnyClass))", "[ USING ] Delegate")
        }
    }
    private weak var _delegate: ReachabilityHelperDelegate?
    
    // MARK: - Life Cycle
    
    // 初始化
    private init(reachability: SCNetworkReachability) {
        self.reachability = reachability
    }
    
    // 释放
    deinit {
        stopMonitor()
    }
    
    // MARK: -
    
    /**
     检查是否可以连接到指定主机域名
     
     - parameters:
     
        - hostName: 指定主机域名
     
     - returns: ReachabilityHelper 实例
     */
    public convenience init?(hostName: String) {
        guard let reachability = SCNetworkReachabilityCreateWithName(kCFAllocatorDefault, hostName) else {
            return nil
        }
        
        self.init(reachability: reachability)
    }
    
    /**
     检查是否可以连接到默认路由
     
     - returns: ReachabilityHelper 实例
     */
    public convenience init?() {
        var zeroAddress = sockaddr()
        zeroAddress.sa_len = UInt8(MemoryLayout<sockaddr>.size)
        zeroAddress.sa_family = sa_family_t(AF_INET)
        
        guard let reachability = SCNetworkReachabilityCreateWithAddress(kCFAllocatorDefault, &zeroAddress) else {
            return nil
        }
        
        self.init(reachability: reachability)
    }
    
    // MARK: - Private Methods
    
    // 当前状态
    private func currentStatus() -> ReachabilityStatus {
        var status = ReachabilityStatus.unknown
        var flags = SCNetworkReachabilityFlags()
        
        // 获取当前标记对应的网络可达性状态
        if SCNetworkReachabilityGetFlags(reachability, &flags) {
            status = networkStatusForFlags(flags)
        }
        
        return status
    }
    
    // 根据标记获取网络状态
    private func networkStatusForFlags(_ flags: SCNetworkReachabilityFlags) -> ReachabilityStatus {
        if ((flags.rawValue & SCNetworkReachabilityFlags.reachable.rawValue) == 0) { // 网络不通
            return .none
        }
        
        // 网络可达性状态
        var status = ReachabilityStatus.unknown
        
        if ((flags.rawValue & SCNetworkReachabilityFlags.connectionRequired.rawValue) == 0) { // 可连上目标主机
            status = .wifi
        }
        
        if ((((flags.rawValue & SCNetworkReachabilityFlags.connectionOnDemand.rawValue) != 0) || (flags.rawValue & SCNetworkReachabilityFlags.connectionOnTraffic.rawValue) != 0)) { // 按需连接状态（CFSocketStream）
            if ((flags.rawValue & SCNetworkReachabilityFlags.interventionRequired.rawValue) == 0) { // 不需用户干预
                status = .wifi
            }
        }
        
        if ((flags.rawValue & SCNetworkReachabilityFlags.isWWAN.rawValue) == SCNetworkReachabilityFlags.isWWAN.rawValue) { // 使用的是 WWAN 网络接口（CFNetwork）
            // 获取当前数据网络的类型
            let info = CTTelephonyNetworkInfo()
            
            // 定义网络类型
            let wwan2G = [CTRadioAccessTechnologyGPRS, CTRadioAccessTechnologyEdge, CTRadioAccessTechnologyCDMA1x]
            let wwan3G = [CTRadioAccessTechnologyWCDMA, CTRadioAccessTechnologyHSDPA, CTRadioAccessTechnologyHSUPA, CTRadioAccessTechnologyCDMAEVDORev0, CTRadioAccessTechnologyCDMAEVDORevA, CTRadioAccessTechnologyCDMAEVDORevB, CTRadioAccessTechnologyeHRPD]
            let wwan4G = [CTRadioAccessTechnologyLTE]
            
            // 当前网络类型
            let technology = info.currentRadioAccessTechnology!
            
            // 获取当前网络状态
            if wwan2G.contains(technology) {
                status = .wwan2G
            } else if wwan3G.contains(technology) {
                status = .wwan3G
            } else if wwan4G.contains(technology) {
                status = .wwan4G
            }
        }
        
        return status
    }
    
    // 网络可达性状态改变
    private func reachabilityChanged() {
        
        log("[ STATUS ] Changed", "[ TYPE ] " + previousStatus.description)

        // 使用代理回调
        DispatchQueue.main.async {
            if self.delegates.count != 0 {
                for delegate in self.delegates.allObjects {
                    let delegate = delegate as! ReachabilityHelperDelegate
                    delegate.reachabilityHelper(self, reachabilityStatusChanged: self.previousStatus)
                }
            }
        }
        
        // 使用闭包回调
        DispatchQueue.main.async {
            if self.closures.count != 0 {
                let keys = self.closures.keys.sorted()
                let monitors:[String] = self.monitors.keyEnumerator().allObjects as! [String]
                for key in keys {
                    if monitors.contains(key) {
                        let closure = self.closures[key] as! ReachabilityStatusChangedClosure
                        closure(self.previousStatus)
                    } else {
                        self.closures.removeValue(forKey: key)
                    }
                }
            }
        }
        
        // 使用通知回调
        DispatchQueue.main.async {
            NotificationCenter.default.post(name: Notification.Name.ReachabilityStatusChangedNotification, object: self)
        }
    }
    
    // 调试打印
    private func log(_ strings: String ...) {
        if type(of: self).debugMode {
            for string in strings {
                print("[ FayLIB ][ REACHABILITY ]" + string + ".")
            }
        }
    }
    
    // MARK: - Public Methods
    
    /**
     打开网络可达性监听
     
     - returns: 打开监听是否成功
     */
    @discardableResult
    public func startMonitor() -> Bool {
        stopMonitor()
        
        var started = false
        
        // 回调网络可达性状态改变
        reachabilityStatusCallback = {
            // 判断当前网络可达性状态是否发生了改变
            if self.previousStatus != self.currentStatus() {
                self.previousStatus = self.currentStatus()
            }
            
            // 网络可达性状态改变时，发起回调
            self.reachabilityChanged()
        }
        
        // 获取网络可达性上下文
        var context = SCNetworkReachabilityContext(version: 0, info: Unmanaged.passRetained(self).toOpaque(), retain: { (info: UnsafeRawPointer) -> UnsafeRawPointer in
            let unmanagedWeakifiedReachability = Unmanaged<ReachabilityHelper>.fromOpaque(info)
            _ = unmanagedWeakifiedReachability.retain()
            return UnsafeRawPointer(unmanagedWeakifiedReachability.toOpaque())
        }, release: { (info: UnsafeRawPointer) -> Void in
            let unmanagedWeakifiedReachability = Unmanaged<ReachabilityHelper>.fromOpaque(info)
            unmanagedWeakifiedReachability.release()
        }, copyDescription: nil)
        
        // 网络可达性状态发生变化的回调
        let callback: SCNetworkReachabilityCallBack = { _, flags, info in
            guard let info = info else {
                return
            }
            
            let helper = Unmanaged<ReachabilityHelper>.fromOpaque(info).takeUnretainedValue()
            helper.reachabilityStatusCallback!()
        }
        
        // 设置网络状态改变的回调
        if SCNetworkReachabilitySetCallback(reachability, callback, &context) {
            if SCNetworkReachabilityScheduleWithRunLoop(reachability, CFRunLoopGetCurrent(), CFRunLoopMode.defaultMode.rawValue) {
                started = true
                
                log("[ MONITOR ] Started")
                
                // 后台获取网络可达性的标记并设置回调
                DispatchQueue.global(qos: .background).async {
                    var flags = SCNetworkReachabilityFlags()
                    if SCNetworkReachabilityGetFlags(self.reachability, &flags) {
                        self.reachabilityStatusCallback!()
                    }
                }
            }
        }
        
        return started
    }
    
    /**
     关闭网络可达性监听
     
     - returns: 关闭监听是否成功
     */
    @discardableResult
    public func stopMonitor() -> Bool {
        var stopped = false
        
        if SCNetworkReachabilityUnscheduleFromRunLoop(reachability, CFRunLoopGetCurrent(), CFRunLoopMode.defaultMode.rawValue) {
            stopped = true
            
            log("[ MONITOR ] Stopped")
        }
        
        return stopped
    }
    
    /**
     添加网络可达性状态改变的监听者并设置回调
     
     ## 此方法用于将监听者添加到网络可达性状态监听队列，所有实现此方法的类都会接收到网络可达性状态改变的消息
     
     若此监听者被从内存中释放，监听队列会自动移除此监听者，不需手动管理
     
     - parameters:
     
        - monitor: 网络可达性监听者
     
        - closure: 网络可达性状态发生改变时的回调
     
        - status: 网络可达性状态
     
     - warning: 使用闭包监听网络可达性状态时实现
     
     网络可达性助手集成了代理，闭包，通知三种方式进行网络可达性状态监听，使用时只需实现其中一种方式即可
     */
    public func addMonitor(_ monitor: AnyObject, reachabilityStatusChangedClosure closure: @escaping (_ status: ReachabilityStatus) -> Void) {
        monitors.setObject(monitor, forKey: kFLReachabilityStatusChangedClosure + String(closureCount) as AnyObject)
        closures.updateValue(closure as AnyObject, forKey: kFLReachabilityStatusChangedClosure + String(closureCount))
        closureCount += 1
        
        log("[ MONITOR ] Added", "[ CLASS ] \(NSStringFromClass(type(of: monitor)))", "[ USING ] Closure")
    }
    
    /**
     添加网络可达性状态改变的监听者
     
     ## 此方法用于将监听者添加到网络可达性状态监听队列，所有实现此方法的类都会接收到网络可达性状态改变的消息
     
     使用此方法时不需实现 `addReachabilityStatusChangedObserver(_:)` 方法
     
     - parameters:
     
        - monitor: 网络可达性监听者
     
     - warning: 使用通知监听网络可达性状态时实现
     
     网络可达性助手集成了代理，闭包，通知三种方式进行网络可达性状态监听，使用时只需实现其中一种方式即可
     */
    public func addMonitor(_ monitor: AnyObject) {
        NotificationCenter.default.addObserver(monitor, selector: NSSelectorFromString("handleReachabilityStatusChangedNotification:"), name: Notification.Name.ReachabilityStatusChangedNotification, object: nil)
        
        log("[ MONITOR ] Added", "[ CLASS ] \(NSStringFromClass(type(of: monitor)))", "[ USING ] Notification")
    }
    
    /**
     移除网络可达性状态改变的监听者
     
     ## 此方法用于将监听者从网络可达性状态监听队列移除
     
     使用此方法时不需实现 `removeReachabilityStatusChangedObserver(_:)` 方法
     
     - parameters:
     
        - monitor: 网络可达性监听者
     
     - warning: 使用通知监听网络可达性状态时实现
     
     网络可达性助手集成了代理，闭包，通知三种方式进行网络可达性状态监听，使用时只需实现其中一种方式即可
     */
    public func removeMonitor(_ monitor: AnyObject) {
        NotificationCenter.default.removeObserver(monitor, name: Notification.Name.ReachabilityStatusChangedNotification, object: nil)
        
        log("[ MONITOR ] Removed", "[ CLASS ] \(NSStringFromClass(type(of: monitor)))", "[ USING ] Notification")
    }
    
    // MARK: -
    
    /**
     当前网络可达性状态
     
     - returns: 网络可达性状态
     
     - warning: 使用通知监听网络可达性状态时实现
     
     网络可达性助手集成了代理，闭包，通知三种方式进行网络可达性状态监听，使用时只需实现其中一种方式即可
     */
    public func currentReachabilityStatus() -> ReachabilityStatus {
        return previousStatus
    }
    
    // MARK: -
    
    /**
     设置调试模式
     
     - parameters:
     
        - openOrNot: 是否打开
     */
    public class func setDebugMode(_ openOrNot: Bool) {
        self.debugMode = openOrNot
    }
}

private extension NSPointerArray {
    func addObject(_ object: AnyObject?) {
        guard let strongObject = object else { return }
        
        let pointer = Unmanaged.passUnretained(strongObject).toOpaque()
        addPointer(pointer)
    }
    
    func insertObject(_ object: AnyObject?, at index: Int) {
        guard index < count, let strongObject = object else { return }
        
        let pointer = Unmanaged.passUnretained(strongObject).toOpaque()
        insertPointer(pointer, at: index)
    }
    
    func replaceObject(at index: Int, withObject object: AnyObject?) {
        guard index < count, let strongObject = object else { return }
        
        let pointer = Unmanaged.passUnretained(strongObject).toOpaque()
        replacePointer(at: index, withPointer: pointer)
    }
    
    func object(at index: Int) -> AnyObject? {
        guard index < count, let pointer = self.pointer(at: index) else { return nil }
        return Unmanaged<AnyObject>.fromOpaque(pointer).takeUnretainedValue()
    }
    
    func removeObject(at index: Int) {
        guard index < count else { return }
        
        removePointer(at: index)
    }
}
