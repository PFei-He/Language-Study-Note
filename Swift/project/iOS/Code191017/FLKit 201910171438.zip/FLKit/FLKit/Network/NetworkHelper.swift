//
//  Copyright (c) 2019 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

import UIKit

/**
 请求方法
 
 ## 定义了 HTTP 协议的请求方法，包括 GET，PUT，POST，DELETE 的请求类型
 */
public enum NetworkRequestMethod: CustomStringConvertible {
    case Get, Put, Post, Delegate
    public var description: String {
        switch self {
        case .Get:
            return "GET"
        case .Put:
            return "PUT"
        case .Post:
            return "POST"
        case .Delegate:
            return "DELECT"
        }
    }
}

public protocol NetworkHelperDelegate: class {
    
    /**
     请求成功的代理方法
     
     ## 该方法用于接收请求成功的响应对象，该对象包含有当前的请求任务，请求成功的结果
     
     - parameters:
     
        - networkHelper: 网络请求助手
     
        - dataTask: 接收响应的任务
     
        - resultData: 请求成功的结果
     
     - warning: 使用代理操作网络请求时实现
     
     网络请求助手集成了代理，闭包，通知三种方式进行网络请求操作，使用时只需实现其中一种方式即可
     */
    func networkHelper(_ networkHelper: NetworkHelper, dataTask task: URLSessionDataTask, resultData data: Any)
    
    /**
     请求失败的代理方法
     
     ## 该方法用于接收请求失败的响应对象，该对象包含有当前的请求任务，请求失败的结果
     
     - parameters:
     
        - networkHelper: 网络请求助手
     
        - dataTask: 接收响应的任务
     
        - error: 请求失败的结果
     
     - warning: 使用代理操作网络请求时实现
     
     网络请求助手集成了代理，闭包，通知三种方式进行网络请求操作，使用时只需实现其中一种方式即可
     */
    func networkHelper(_ networkHelper: NetworkHelper, _ dataTask: URLSessionDataTask, _ error: Error)
}

public class NetworkHelper {
    
    /**
     请求方法
     
     ## 默认使用 GET 方法进行请求
     */
    public var requestMethod = NetworkRequestMethod.Get
    
    /**
     请求地址
     
     ## 接收请求的服务器地址
     */
    public var requestURL = String()
    
    /**
     超时时隔
     
     ## 不设置默认请求时间为120秒
     */
    var timeoutInterval: TimeInterval = 120
    
    /**
     请求参数
     
     ## 发送到服务器的请求的参数
     */
    var requestParams = [String: Any]()
    
    /*!
     网络请求助手代理
     
     @warning 使用代理操作网络请求时实现
     
     网络请求助手集成了代码块，代理，通知三种方式进行网络请求操作，使用时只需实现其中一种方式即可
     */
    public weak var delegate: NetworkHelperDelegate?
    
    func request() -> URLSessionDataTask {
        
        // 创建请求
        let session = URLSession.shared
        let url = URL(string: requestURL)!
        var request = URLRequest(url: url)
        
        // 设置请求方法
        request.httpMethod = requestMethod.description
        
        // 设置超时时隔
        request.timeoutInterval = timeoutInterval
        
        // 设置请求头
        
        // 设置请求参数
//        request.httpBody =
        
        var dataTask: URLSessionDataTask?
        dataTask = session.dataTask(with: request, completionHandler: { (data, response, error) in
            if error != nil {
                
            } else {
                if let resultData = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) {
                    DispatchQueue.main.async {
                        self.delegate?.networkHelper(self, dataTask: dataTask!, resultData: resultData)
                    }
                }
            }
        })
        
        dataTask?.resume()
        
        return dataTask!
    }
}
