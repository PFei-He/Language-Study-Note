//
//  Copyright (c) 2019 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

public protocol TransformType {
    associatedtype Object
    associatedtype JSON
    
    func from(JSON json: Any?) -> Object?
    func toJSON(_ value: Object?) -> JSON?
}

import Foundation

open class Transform<T: Codable>: TransformType {
    
    public typealias Object = T
    public typealias JSON = Any
    
    public init() {}
    
    /**
     转化 JSON 到数据模型
     
     - Parameters:
     
        - JSON: 需要转化的数据
     */
    open func from(JSON json: Any?) -> Object? {
        var _data: Data? = nil
        switch json {
        case let dict as [String : Any]:
            _data = try? JSONSerialization.data(withJSONObject: dict, options: [])
        case let array as [[String : Any]]:
            _data = try? JSONSerialization.data(withJSONObject: array, options: [])
        default:
            _data = nil
        }
        guard let data = _data else { return nil }
        
        do {
            let decoder = JSONDecoder()
            let item = try decoder.decode(T.self, from: data)
            return item
        } catch {
            return nil
        }
    }
    
    /**
     将数据模型转化为 JSON
     
     - returns: JSON 数据
     */
    open func toJSON(_ value: T?) -> JSON? {
        guard let item = value else {
            return nil
        }
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(item)
            let dictionary = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
            return dictionary
        } catch {
            return nil
        }
    }
}
