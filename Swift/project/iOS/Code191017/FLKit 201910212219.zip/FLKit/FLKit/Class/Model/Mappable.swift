//
//  Copyright (c) 2019 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

import Foundation

extension Decodable {
    
    // MARK: - Private Methods
    
    // 解析 JSON
    fileprivate static func parse(JSON json: Any) -> Data {
        var data: Data
        do {
            switch json {
            case let dictionary as [String : Any]:
                data = try JSONSerialization.data(withJSONObject: dictionary, options: [])
            case let array as [[String : Any]]:
                data = try JSONSerialization.data(withJSONObject: array, options: [])
            default:
                data = try JSONSerialization.data(withJSONObject: json, options: [])
            }
        } catch {
            fatalError("")
        }
        return data
    }
    
    // 解码，将数据转化为模型
    fileprivate static func decode(data: Data) -> Self {
        do {
            return try JSONDecoder().decode(Self.self, from: data)
        } catch {
            fatalError("")
        }
    }
    
    // MARK: - Public Methods
    
    /**
     初始化
     
     - Parameters:
     
        - JSON: 需要转化的数据
     
     - returns: Decodable 实例
     */
    public init(JSON json: Any) {
        let data = Self.parse(JSON: json)
        self = Self.decode(data: data)
    }
    
    /**
     转化 JSON 到数据模型
     
     - Parameters:
     
        - JSON: 需要转化的数据
     */
    public mutating func from(JSON json: Any) {
        let data = Self.parse(JSON: json)
        self = Self.decode(data: data)
    }
}

extension Encodable {
    
    // MARK: - Private Methods
    
    // 编码
    fileprivate func encode() -> Any {
        do {
            let data = try JSONEncoder().encode(self)
            let dictionary = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
            return dictionary
        } catch {
            return [:]
        }
    }
    
    // MARK: - Public Methods
    
    /**
     将数据模型转化为 JSON
     
     - returns: JSON 数据
     */
    public func toJSON() -> Any {
        return self.encode()
    }
}

public protocol Mappable: Codable {}

extension Mappable {
    
    /**
     JSON 数据
     
     ## 对本类的属性 / 需要解析的 JSON 数据进行转化操作
     
        Setter: 将 JSON 数据的键值转化为数据模型的属性 (JSON -> Model)
     
        Getter: 将数据模型的属性转化为 JSON 数据的键值 (Model -> JSON)
     
     - returns: 转化后的 JSON 数据
     */
    public var JSON: Any {
        get {
            return self.encode()
        }
        set {
            let data = Self.parse(JSON: newValue)
            self = Self.decode(data: data)
        }
    }
}
