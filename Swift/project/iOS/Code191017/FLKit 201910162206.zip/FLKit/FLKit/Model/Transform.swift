//
//  Copyright (c) 2019 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

//import Foundation
//
//fileprivate enum MapError: Error {
//    case jsonToModelFail    //json转model失败
//    case jsonToDataFail     //json转data失败
//    case dictToJsonFail     //字典转json失败
//    case jsonToArrFail      //json转数组失败
//    case modelToJsonFail    //model转json失败
//}
//
//public protocol Mappable: Codable {
////    func modelMapFinished()
////    mutating func structMapFinished()
//}
//
//extension Mappable {
//
////    func modelMapFinished() {}
//
////    mutating func structMapFinished() {}
//
//    //模型转字典
//    public func reflectToDict() -> [String:Any] {
//        let mirro = Mirror(reflecting: self)
//        var dict = [String:Any]()
//        for case let (key?, value) in mirro.children {
//            dict[key] = value
//        }
//        return dict
//    }
//
//
//    //字典转模型
//    public static func mapFromDict<T : Mappable>(_ dict : [String:Any], _ type:T.Type) throws -> T {
//        guard let JSONString = dict.toJSONString() else {
////            print(MapError.dictToJsonFail)
//            throw MapError.dictToJsonFail
//        }
//        guard let jsonData = JSONString.data(using: .utf8) else {
////            print(MapError.jsonToDataFail)
//            throw MapError.jsonToDataFail
//        }
//        let decoder = JSONDecoder()
//
//        if let obj = try? decoder.decode(type, from: jsonData) {
////            var vobj = obj
//            let vobj = obj
//            let mirro = Mirror(reflecting: vobj)
//            if mirro.displayStyle == Mirror.DisplayStyle.struct {
////                vobj.structMapFinished()
//            }
//            if mirro.displayStyle == Mirror.DisplayStyle.class {
////                vobj.modelMapFinished()
//            }
//            return vobj
//        }
////        print(MapError.jsonToModelFail)
//        throw MapError.jsonToModelFail
//    }
//
//
//    //JSON转模型
//    public static func mapFromJson<T : Mappable>(_ JSONString : String, _ type:T.Type) throws -> T {
//        guard let jsonData = JSONString.data(using: .utf8) else {
//            print(MapError.jsonToDataFail)
//            throw MapError.jsonToDataFail
//        }
//        let decoder = JSONDecoder()
//        if let obj = try? decoder.decode(type, from: jsonData) {
//            return obj
//        }
////        print(MapError.jsonToModelFail)
//        throw MapError.jsonToModelFail
//    }
//
//
//    //模型转json字符串
//    public func toJSONString() throws -> String {
//        if let str = self.reflectToDict().toJSONString() {
//            return str
//        }
////        print(MapError.modelToJsonFail)
//        throw MapError.modelToJsonFail
//    }
//}
//
//
//extension Array {
//
//    public func toJSONString() -> String? {
//        if (!JSONSerialization.isValidJSONObject(self)) {
////            print("dict转json失败")
//            return nil
//        }
//        if let newData : Data = try? JSONSerialization.data(withJSONObject: self, options: []) {
//            let JSONString = NSString(data:newData as Data,encoding: String.Encoding.utf8.rawValue)
//            return JSONString as String? ?? nil
//        }
////        print("dict转json失败")
//        return nil
//    }
//
//    public func mapFromJson<T : Decodable>(_ type:[T].Type) throws -> Array<T> {
//        guard let JSONString = self.toJSONString() else {
////            print(MapError.dictToJsonFail)
//            throw MapError.dictToJsonFail
//        }
//        guard let jsonData = JSONString.data(using: .utf8) else {
////            print(MapError.jsonToDataFail)
//            throw MapError.jsonToDataFail
//        }
//        let decoder = JSONDecoder()
//        if let obj = try? decoder.decode(type, from: jsonData) {
//            return obj
//        }
////        print(MapError.jsonToArrFail)
//        throw MapError.jsonToArrFail
//    }
//}
//
//
//extension Dictionary {
//    public func toJSONString() -> String? {
//        if (!JSONSerialization.isValidJSONObject(self)) {
////            print("dict转json失败")
//            return nil
//        }
//        if let newData : Data = try? JSONSerialization.data(withJSONObject: self, options: []) {
//            let JSONString = NSString(data:newData as Data,encoding: String.Encoding.utf8.rawValue)
//            return JSONString as String? ?? nil
//        }
////        print("dict转json失败")
//        return nil
//    }
//}
//
//
//extension String {
//    public func toDict() -> [String:Any]? {
//        guard let jsonData:Data = self.data(using: .utf8) else {
////            print("json转dict失败")
//            return nil
//        }
//        if let dict = try? JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) {
//            return dict as? [String : Any] ?? ["":""]
//        }
////        print("json转dict失败")
//        return nil
//    }
//}

public protocol TransformType {
    associatedtype Object
    associatedtype JSON
    
    func fromJSON(_ value: Any?) -> Object?
    func toJSON(_ value: Object?) -> JSON?
}

import Foundation

open class Transform<T: Codable>: TransformType {
    
    public typealias Object = T
    public typealias JSON = Any
    
    public init() {}
    
    open func fromJSON(_ value: Any?) -> Object? {
        var _data: Data? = nil
        switch value {
        case let dict as [String : Any]:
            _data = try? JSONSerialization.data(withJSONObject: dict, options: [])
        case let array as [[String : Any]]:
            _data = try? JSONSerialization.data(withJSONObject: array, options: [])
        default:
            _data = nil
        }
        guard let data = _data else { return nil }
        
        do {
            let decoder = JSONDecoder()
            let item = try decoder.decode(T.self, from: data)
            return item
        } catch {
            return nil
        }
    }
    
    open func toJSON(_ value: T?) -> JSON? {
        guard let item = value else {
            return nil
        }
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(item)
            let dictionary = try JSONSerialization.jsonObject(with: data, options: .allowFragments)
            return dictionary
        } catch {
            return nil
        }
    }
}
